from pathlib import Path
import pandas as pd
import math

CAPITAL = 20_000.0
TARGET_STOCKS = 10
TARGET_PER_STOCK = CAPITAL / TARGET_STOCKS
TOP10_FILE = Path("live_plan2_top10.csv")

if not TOP10_FILE.exists():
    raise SystemExit("live_plan2_top10.csv not found")

df = pd.read_csv(TOP10_FILE)
symbol_col = next((c for c in ["Stock", "Symbol", "symbol", "Ticker", "ticker"] if c in df.columns), None)
price_col = next((c for c in ["Live Price", "Price", "price", "Close", "close"] if c in df.columns), None)

if symbol_col is None or price_col is None:
    raise SystemExit(f"Required columns not found. Columns: {list(df.columns)}")

df = df[[symbol_col, price_col]].copy()
df.columns = ["Stock", "Live Price"]
df["Live Price"] = pd.to_numeric(df["Live Price"], errors="coerce")
df = df.dropna(subset=["Live Price"])
df = df[df["Live Price"] > 0].reset_index(drop=True)

# Use the current Plan 2 portfolio order. The live screener already outputs
# the final 10 stocks in rank order. Do not add extra stocks here.
selected = df.head(TARGET_STOCKS).copy()
if len(selected) < TARGET_STOCKS:
    raise SystemExit(f"Only {len(selected)} valid Plan 2 stocks available; need {TARGET_STOCKS}.")

selected.insert(0, "Portfolio Rank", range(1, TARGET_STOCKS + 1))
selected["Target Allocation"] = TARGET_PER_STOCK
selected["Shares"] = (selected["Target Allocation"] / selected["Live Price"]).apply(math.floor)
selected["Invested"] = selected["Shares"] * selected["Live Price"]
selected["Leftover Within Target"] = selected["Target Allocation"] - selected["Invested"]
selected["Executable"] = selected["Shares"] >= 1

# No reallocation: leftover cash remains cash. If a stock is too expensive
# to buy with its ₹2,000 target, it is explicitly flagged rather than forcing
# another stock into the portfolio.
if not selected["Executable"].all():
    bad = selected.loc[~selected["Executable"], "Stock"].tolist()
    print("WARNING: target allocation cannot buy at least one whole share for:", ", ".join(bad))

invested = float(selected["Invested"].sum())
leftover_cash = CAPITAL - invested

selected["Capital"] = CAPITAL
selected["Total Portfolio Leftover Cash"] = leftover_cash
selected.to_csv("capital_auto_allocation.csv", index=False)

summary = pd.DataFrame([{
    "Portfolio Stocks": TARGET_STOCKS,
    "Capital": CAPITAL,
    "Target per Stock": TARGET_PER_STOCK,
    "Executable Stocks": int(selected["Executable"].sum()),
    "Unexecutable Stocks": int((~selected["Executable"]).sum()),
    "Invested": invested,
    "Leftover Cash": leftover_cash,
    "Capital Used %": invested / CAPITAL * 100,
}])
summary.to_csv("capital_execution_test.csv", index=False)

print("\nPLAN 2 CAPITAL ALLOCATION")
print("=========================")
print(selected[["Portfolio Rank", "Stock", "Live Price", "Target Allocation", "Shares", "Invested", "Executable"]].to_string(index=False))
print(f"\nCapital: ₹{CAPITAL:,.2f}")
print(f"Invested: ₹{invested:,.2f}")
print(f"Leftover cash: ₹{leftover_cash:,.2f}")
print(f"Executable stocks: {int(selected['Executable'].sum())}/{TARGET_STOCKS}")
print("\nCreated capital_auto_allocation.csv")
print("Created capital_execution_test.csv")
